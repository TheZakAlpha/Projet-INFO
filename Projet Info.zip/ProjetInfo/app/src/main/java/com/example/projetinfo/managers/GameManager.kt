package com.example.projetinfo.managers

import android.graphics.Canvas
import android.graphics.Paint
import com.example.projetinfo.models.*
import com.example.projetinfo.models.powerups.SpeedBoost
import com.example.projetinfo.utils.PowerUpFactory

class GameManager {

    // Joueur
    lateinit var player: PlayerShip

    // Liste d'ennemis actifs
    val enemies: MutableList<Enemy> = mutableListOf()

    // Gestionnaire de tirs
    val projectileManager = ProjectileManager()

    // Gestionnaire PowerUps
    val powerUps: MutableList<PowerUp> = mutableListOf()
    private var hasSpawnedPowerUp = false

    //Gestionnaire des Spawn de PowerUp
    private var lastPowerUpTime: Long = 0

    // Gestionnaire du PowerUpManager
    private val powerUpManager = PowerUpManager()

    // Score
    var score: Int = 0

    // Niveau actuel
    private var currentLevel: Int = 1

    // Intervalle entre deux tirs du joueur (en ms)
    private var playerLastShotTime: Long = 0
    private val playerShootInterval: Long = 500



    // Initialisation de la partie
    val levelManager = LevelManager()

    // Lancement d'une partie complète (appelé depuis le menu ou GameOver)
    fun startGame() {
        levelManager.reset()
        val level = levelManager.loadLevel(levelManager.getCurrentLevel())
        currentLevel = levelManager.getCurrentLevel()


        enemies.clear()
        enemies.addAll(level.enemies)
        enemies.add(level.boss)

        player = PlayerShip(500f, 1500f, 0f, 3)
    }
    fun loadNextLevel() {
        // On met à jour le numéro du niveau courant
        currentLevel = levelManager.getCurrentLevel()

        // On charge les ennemis du niveau
        val level = levelManager.loadLevel(currentLevel)

        enemies.clear()
        enemies.addAll(level.enemies)
        enemies.add(level.boss)
    }




    // Mise à jour du jeu à chaque frame
    fun update() {

        if (enemies.none { it is BossEnemy || it.health > 0 }) {
            levelManager.nextLevel()
            loadNextLevel()
        }

        // Mise à jour du joueur (si déplacement)
        // player.move() // on le contrôle manuellement plus tard

        // Déplacement des ennemis
        enemies.forEach { it.move() }

        val currentTime = System.currentTimeMillis()

        // Pour chaque ennemi dans la liste
        enemies.forEach { enemy ->

            // Vérifie si l'ennemi peut tirer (intervalle respecté)
            if (currentTime - enemy.lastShotTime > enemy.shootInterval) {

                // L'ennemi tire un ou plusieurs projectiles
                val enemyProjectiles = enemy.shoot()

                // On ajoute chaque projectile dans le ProjectileManager
                enemyProjectiles.forEach { projectileManager.addProjectile(it) }

                // On met à jour l'heure du dernier tir de cet ennemi
                enemy.lastShotTime = currentTime
            }
        }

        powerUpManager.update(currentTime, player, currentLevel)

        // PowerUp spawn tous les 15 secondes si aucun actif
        val spawnInterval = 15_000
        if (System.currentTimeMillis() - lastPowerUpTime > spawnInterval && powerUps.isEmpty()) {
            powerUps.add(PowerUpFactory.generateRandomPowerUp(currentLevel))
            lastPowerUpTime = System.currentTimeMillis()
        }



        // Tir automatique Player

        if (currentTime - playerLastShotTime > playerShootInterval) {
            val shots = player.shoot()
            shots.forEach { projectileManager.addProjectile(it) }
            playerLastShotTime = currentTime
        }


        // Mise à jour des tirs
        projectileManager.update()

        // Collisions : tirs du joueur contre ennemis
        val projectilesToRemove = mutableListOf<Projectile>()
        val enemiesToRemove = mutableListOf<Enemy>()

        for (projectile in projectileManager.getProjectiles()) {
            if (projectile.fromPlayer) {
                for (enemy in enemies) {
                    if (checkCollision(projectile.x, projectile.y, enemy.x, enemy.y)) {
                        enemy.health -= projectile.damage
                        projectilesToRemove.add(projectile)
                        if (enemy.health <= 0) {
                            enemiesToRemove.add(enemy)
                            score += 100 // points à ajuster
                        }
                        break // un projectile touche un seul ennemi
                    }
                }
            } else {
                // Tirs ennemis contre le joueur
                if (checkCollision(projectile.x, projectile.y, player.x, player.y)) {
                    if (player.hasShield) {
                        player.hasShield = false // annule le dégât
                    } else {
                        player.lives -= projectile.damage
                    }
                    projectilesToRemove.add(projectile)
                }
            }
        }

        // Apparition d’un power-up au niveau 2
        if (currentLevel == 2 && !hasSpawnedPowerUp) {
            powerUps.add(SpeedBoost(x = 500f, y = 800f))
            hasSpawnedPowerUp = true
        }

        // Vérifie expiration ou collision
        val toRemove = mutableListOf<PowerUp>()
        powerUps.forEach { powerUp ->
            if (powerUp.isExpired()) {
                toRemove.add(powerUp)
            } else if (checkCollision(player.x, player.y, powerUp.x, powerUp.y)) {
                powerUp.applyEffect(player)
            toRemove.add(powerUp)
            }
        }
        powerUps.removeAll(toRemove)


        // Nettoyage
        projectilesToRemove.forEach { projectileManager.removeProjectile(it) }
        enemiesToRemove.forEach { enemies.remove(it) }
    }

    // Dessin du jeu à chaque frame
    fun draw(canvas: Canvas, paint: Paint) {
        player.draw(canvas, paint)
        enemies.forEach { it.draw(canvas, paint) }
        projectileManager.draw(canvas, paint)
        powerUpManager.draw(canvas, paint)


        // Tu peux aussi dessiner le score ici plus tard
    }

    // Fonction de détection de collision simplifiée (boîtes englobantes)
    fun checkCollision(aX: Float, aY: Float, bX: Float, bY: Float, radius: Float = 50f): Boolean {
        val dx = aX - bX
        val dy = aY - bY
        val distance = Math.sqrt((dx * dx + dy * dy).toDouble())
        return distance < radius
    }


}
