package com.example.projetinfo.managers

import com.example.projetinfo.models.*
import com.example.projetinfo.models.patterns.*

class LevelManager {

    // Numéro du niveau courant

    private var currentLevel: Int = 1

    fun reset() {
        currentLevel = 1
    }

    // Permet d'accéder au niveau courant
    fun getCurrentLevel(): Int = currentLevel

    // Passe au niveau suivant
    fun nextLevel() {
        currentLevel++
    }

    // Charge un niveau spécifique (en fonction de son numéro)
    fun loadLevel(levelNumber: Int): Level {
        return when (levelNumber) {
            1 -> createLevel1()
            2 -> createLevel2()
            3 -> createLevel3()
            else -> createLevel1() // par défaut on recommence au 1
        }
    }

    // Exemple : Niveau 1 avec des aliens simples et un boss de base
    private fun createLevel1(): Level {
        val enemies = listOf(
            AlienEnemy(200f, 100f, 3f),
            AlienEnemy(400f, 100f, 3f)
        )

        val boss = BossEnemy(
            x = 500f,
            y = 80f,
            speed = 2f,
            shootPattern = SingleShotPattern() // pattern simple
        )

        return Level(enemies, boss)
    }

    // Exemple : Niveau 2 avec des ennemis plus rapides et un boss en rafale
    private fun createLevel2(): Level {
        val enemies = listOf(
            AlienEnemy(100f, 100f, 5f),
            AlienEnemy(300f, 120f, 5f),
            AlienEnemy(500f, 90f, 5f)
        )

        val boss = BossEnemy(
            x = 500f,
            y = 50f,
            speed = 3f,
            shootPattern = BurstShotPattern() // pattern en rafale
        )

        return Level(enemies, boss)
    }

    // Exemple : Niveau 3 avec boss à tir circulaire
    private fun createLevel3(): Level {
        val enemies = listOf(
            AlienEnemy(100f, 100f, 4f),
            AlienEnemy(250f, 120f, 4f),
            AlienEnemy(400f, 140f, 4f),
            AlienEnemy(550f, 160f, 4f)
        )

        val boss = BossEnemy(
            x = 500f,
            y = 40f,
            speed = 2f,
            shootPattern = DiagonalSpreadPattern() // tir en éventail
        )

        return Level(enemies, boss)
    }
}
