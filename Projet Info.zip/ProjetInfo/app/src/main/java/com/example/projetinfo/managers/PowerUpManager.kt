package com.example.projetinfo.managers

import android.graphics.Canvas
import android.graphics.Paint
import com.example.projetinfo.models.PlayerShip
import com.example.projetinfo.models.PowerUp
import com.example.projetinfo.utils.PowerUpFactory

class PowerUpManager {

    private val powerUps = mutableListOf<PowerUp>()
    private var lastSpawnTime: Long = 0
    private val spawnInterval = 15_000L // Toutes les 15 sec
    private val powerUpLifetime = 10_000L

    /**
     * Met à jour l’état des power-ups : apparition, expiration, collision
     */
    fun update(currentTime: Long, player: PlayerShip, level: Int) {
        // Supprime les expirés
        powerUps.removeAll { it.isExpired() }

        // Apparition automatique si délai dépassé et aucun à l’écran
        if ((currentTime - lastSpawnTime > spawnInterval) && powerUps.isEmpty()) {
            val newPowerUp = PowerUpFactory.generateRandomPowerUp(level)
            newPowerUp.setLifetime(powerUpLifetime)
            powerUps.add(newPowerUp)
            lastSpawnTime = currentTime
        }

        // Collision avec le joueur
        val collected = powerUps.filter { checkCollision(player.x, player.y, it.x, it.y) }
        collected.forEach {
            it.applyEffect(player)
        }

        // Supprime les ramassés
        powerUps.removeAll(collected)
    }

    /**
     * Dessine tous les power-ups actifs à l’écran
     */
    fun draw(canvas: Canvas, paint: Paint) {
        powerUps.forEach { it.draw(canvas, paint) }
    }

    private fun checkCollision(aX: Float, aY: Float, bX: Float, bY: Float, radius: Float = 50f): Boolean {
        val dx = aX - bX
        val dy = aY - bY
        val distance = Math.sqrt((dx * dx + dy * dy).toDouble())
        return distance < radius
    }
}
