package com.example.projetinfo.managers

import android.graphics.Canvas
import android.graphics.Paint
import com.example.projetinfo.models.Projectile

// Cette classe gère tous les projectiles actifs dans le jeu : ceux du joueur et des ennemis
class ProjectileManager {

    // Liste des projectiles actuellement en vol
    private val projectiles: MutableList<Projectile> = mutableListOf()

    // Ajoute un nouveau projectile à la liste
    fun addProjectile(projectile: Projectile) {
        projectiles.add(projectile)
    }

    // Déplace tous les projectiles (appelé à chaque "tick" du jeu)
    fun update() {
        // On fait d'abord bouger chaque projectile
        projectiles.forEach { it.move() }

        // Ensuite, on retire ceux qui sont sortis de l'écran (au-delà du haut ou du bas)
        projectiles.removeAll { it.y < -50 || it.y > 2000 } // valeur à adapter à la taille de ton écran
    }

    // Dessine tous les projectiles à l'écran
    fun draw(canvas: Canvas, paint: Paint) {
        projectiles.forEach { it.draw(canvas, paint) }
    }

    // Fournit la liste des projectiles (lecture seule, pour collisions par exemple)
    fun getProjectiles(): List<Projectile> {
        return projectiles
    }

    // Permet de retirer un projectile (ex. : en cas de collision)
    fun removeProjectile(p: Projectile) {
        projectiles.remove(p)
    }
}
