package com.example.projetinfo.models
import com.example.projetinfo.models.Enemy
import com.example.projetinfo.models.Projectile
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color


class AlienEnemy(
    x: Float,
    y: Float,
    speed: Float
) : Enemy(x, y, speed, health = 1) {

    override fun move() {
        y += speed
    }

    override fun draw(canvas: Canvas, paint: Paint) {
        // Tu peux dessiner l'alien ici
    }

    override fun shoot(): List<Projectile> {
        // Tire un seul projectile vers le bas
        return listOf(
            Projectile(
                x = this.x,
                y = this.y + 20,
                speed = 15f,
                damage = 1,
                fromPlayer = false
            )
        )
    }
}
