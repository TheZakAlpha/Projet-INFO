package com.example.projetinfo.models
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import com.example.projetinfo.models.patterns.ShootPattern

class BossEnemy(
    x: Float,
    y: Float,
    speed: Float,
    val shootPattern: ShootPattern
) : Enemy(x, y, speed, health = 10) {

    override fun move() {
        y += speed / 2 // plus lent
    }

    override fun draw(canvas: Canvas, paint: Paint) {
        // Dessin plus imposant
        paint.color = Color.RED
        canvas.drawRect(x - 40, y - 40, x + 40, y + 40, paint)
    }

    override fun shoot(): List<Projectile> {
        // Utilise le pattern de tir spécifique au boss
        return shootPattern.shootFrom(this)
    }
    override val shootInterval: Long = 1000 // peut être ajusté
}
