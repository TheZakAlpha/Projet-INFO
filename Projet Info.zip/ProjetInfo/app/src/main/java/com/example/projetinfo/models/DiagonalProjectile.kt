package com.example.projetinfo.models

import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.cos
import kotlin.math.sin


class DiagonalProjectile(
    x: Float,
    y: Float,
    speed: Float,
    damage: Int,
    fromPlayer: Boolean,
    private val angle: Float // en degrés, ex. -30°, 30°
) : Projectile(x, y, speed, damage, fromPlayer) {

    override fun move() {
        val radians = Math.toRadians(angle.toDouble())
        x += (speed * cos(radians)).toFloat()
        y += (speed * sin(radians)).toFloat()
    }
}
