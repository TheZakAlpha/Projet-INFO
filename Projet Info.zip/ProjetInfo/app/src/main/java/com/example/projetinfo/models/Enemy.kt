package com.example.projetinfo.models

abstract class Enemy(
    x: Float,
    y: Float,
    speed: Float,
    var health: Int
) : SpaceEntity(x, y, speed) {
    abstract fun shoot(): List<Projectile>
    // Temps du dernier tir (en millisecondes)
    var lastShotTime: Long = 0
    // Intervalle minimal entre deux tirs
    // Peut être redéfini dans les sous-classes si besoin
    open val shootInterval: Long = 2000
}
