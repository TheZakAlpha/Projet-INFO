package com.example.projetinfo.models

// Cette classe contient les données nécessaires pour un niveau
data class Level(
    val enemies: List<Enemy>,    // tous les ennemis "normaux" du niveau
    val boss: BossEnemy          // le boss final de ce niveau
)
