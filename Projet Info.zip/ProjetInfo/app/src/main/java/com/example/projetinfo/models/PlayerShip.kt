package com.example.projetinfo.models

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

// Classe représentant le vaisseau du joueur
class PlayerShip(
    override var x: Float,
    override var y: Float,
    override var speed: Float,
    var lives: Int = 3,
    var hasShield: Boolean = false,
    var multiShot: Boolean = false,
    var multiShotExpiresAt: Long = 0,
    var shootInterval: Long = 500,
    var lastShotTime: Long = 0



) : SpaceEntity(x, y, speed) {
    override fun move() {
        // On ne fait rien ici car le joueur sera contrôlé manuellement
        // Tu peux mettre ici une logique pour bouger avec l'accéléromètre ou autres
    }

    override fun draw(canvas: Canvas, paint: Paint) {
        paint.color = Color.CYAN
        canvas.drawRect(x - 30, y - 30, x + 30, y + 30, paint)
    }
    fun shoot(): List<Projectile> {
        val projectiles = mutableListOf<Projectile>()

        if (multiShot && System.currentTimeMillis() < multiShotExpiresAt) {
            // 3 projectiles en éventail
            projectiles += Projectile(x - 20, y - 40, speed = 20f, damage = 1, fromPlayer = true)
            projectiles += Projectile(x,      y - 40, speed = 20f, damage = 1, fromPlayer = true)
            projectiles += Projectile(x + 20, y - 40, speed = 20f, damage = 1, fromPlayer = true)
        } else {
            // Tir simple
            projectiles += Projectile(x, y - 40, speed = 20f, damage = 1, fromPlayer = true)
        }

        return projectiles
    }


}
