package com.example.projetinfo.models

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

abstract class PowerUp(
    var x: Float,
    var y: Float,
    val durationMs: Long = 5000 // durée de vie avant disparition
) {
    private var lifetimeMs: Long = 10_000
    private var spawnTime: Long = System.currentTimeMillis()

    fun isExpired(): Boolean {
        return System.currentTimeMillis() - spawnTime > lifetimeMs
    }

    fun setLifetime(ms: Long) {
        lifetimeMs = ms
    }



    open fun draw(canvas: Canvas, paint: Paint) {
        // Clignote si proche de l'expiration (< 3s restantes)
        val elapsed = System.currentTimeMillis() - spawnTime
        val remaining = lifetimeMs - elapsed

        if (remaining < 3000) {
            // Clignote toutes les 300ms
            if ((remaining / 300) % 2 == 0L) return
        }

        paint.color = android.graphics.Color.YELLOW
        canvas.drawCircle(x, y, 30f, paint)
    }

    abstract fun applyEffect(player: PlayerShip)
}
