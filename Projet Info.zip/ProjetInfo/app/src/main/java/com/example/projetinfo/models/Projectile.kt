package com.example.projetinfo.models

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

// Classe représentant un projectile (tir de vaisseau)
// Elle hérite de SpaceEntity pour profiter du déplacement et du dessin
open class Projectile(
    override var x: Float,              // Position horizontale initiale
    override var y: Float,              // Position verticale initiale
    override var speed: Float,          // Vitesse de déplacement verticale
    val damage: Int,       // Dégâts infligés à l’impact
    val fromPlayer: Boolean // true = tir allié, false = tir ennemi
) : SpaceEntity(x, y, speed) {

    // Déplacement du projectile : vers le haut (si joueur) ou vers le bas (si ennemi)
    override fun move() {
        if (fromPlayer) {
            y -= speed // tir vers le haut
        } else {
            y += speed // tir vers le bas
        }
    }

    // Dessine le projectile sur le canvas du jeu
    override fun draw(canvas: Canvas, paint: Paint) {
        paint.color = if (fromPlayer) Color.GREEN else Color.RED // vert = joueur, rouge = ennemi
        canvas.drawRect(x - 5, y - 15, x + 5, y + 15, paint) // un petit rectangle vertical
    }
}
