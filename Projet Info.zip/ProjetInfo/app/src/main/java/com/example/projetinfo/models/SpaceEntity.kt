// On place cette classe dans un package logique "models"
package com.example.projetinfo.models

// Ces imports seront utiles pour dessiner des formes dans le jeu
import android.graphics.Canvas
import android.graphics.Paint

// Déclaration d'une classe abstraite : on ne peut pas l'instancier directement.
// Elle représente une entité spatiale générique (joueur, ennemi, projectile…)
abstract class SpaceEntity(
    // Coordonnées de l'entité sur l'écran
    open var x: Float,
    open var y: Float,

    // Vitesse de déplacement
    open var speed: Float
) {
    // Méthode abstraite : chaque sous-classe devra définir COMMENT elle se déplace
    abstract fun move()

    // Méthode abstraite : chaque entité devra savoir COMMENT elle se dessine à l'écran
    abstract fun draw(canvas: Canvas, paint: Paint)
}
