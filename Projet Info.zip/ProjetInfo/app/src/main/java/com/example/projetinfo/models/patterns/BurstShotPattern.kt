package com.example.projetinfo.models.patterns
import com.example.projetinfo.models.Enemy
import com.example.projetinfo.models.Projectile


class BurstShotPattern : ShootPattern {
    override fun shootFrom(enemy: Enemy): List<Projectile> {
        return listOf(
            Projectile(enemy.x - 10, enemy.y + 20, 12f, 1, false),
            Projectile(enemy.x, enemy.y + 20, 12f, 1, false),
            Projectile(enemy.x + 10, enemy.y + 20, 12f, 1, false)
        )
    }
}
