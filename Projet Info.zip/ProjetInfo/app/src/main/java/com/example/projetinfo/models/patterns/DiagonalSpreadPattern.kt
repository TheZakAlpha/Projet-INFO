package com.example.projetinfo.models.patterns
import com.example.projetinfo.models.Enemy
import com.example.projetinfo.models.Projectile
import com.example.projetinfo.models.DiagonalProjectile

class DiagonalSpreadPattern : ShootPattern {
    override fun shootFrom(enemy: Enemy): List<Projectile> {
        return listOf(
            DiagonalProjectile(enemy.x, enemy.y, 10f, 1, false, -45f),
            DiagonalProjectile(enemy.x, enemy.y, 10f, 1, false, 0f),
            DiagonalProjectile(enemy.x, enemy.y, 10f, 1, false, 45f)
        )
    }
}
