package com.example.projetinfo.models.patterns
import com.example.projetinfo.models.Enemy
import com.example.projetinfo.models.Projectile

interface ShootPattern {
    fun shootFrom(enemy: Enemy): List<Projectile>
}