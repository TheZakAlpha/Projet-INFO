package com.example.projetinfo.models.patterns
import com.example.projetinfo.models.Enemy
import com.example.projetinfo.models.Projectile
import com.example.projetinfo.models.patterns.ShootPattern

class SingleShotPattern : ShootPattern {
    override fun shootFrom(enemy: Enemy): List<Projectile> {
        return listOf(
            Projectile(enemy.x, enemy.y + 20, speed = 10f, damage = 1, fromPlayer = false)
        )
    }
}
