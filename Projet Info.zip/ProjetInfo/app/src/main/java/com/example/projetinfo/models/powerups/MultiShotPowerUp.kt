package com.example.projetinfo.models.powerups

import com.example.projetinfo.models.PlayerShip
import com.example.projetinfo.models.PowerUp

class MultiShotPowerUp(x: Float, y: Float) : PowerUp(x, y) {
    override fun applyEffect(player: PlayerShip) {
        player.multiShot = true
        player.multiShotExpiresAt = System.currentTimeMillis() + 30_000
    }
}
