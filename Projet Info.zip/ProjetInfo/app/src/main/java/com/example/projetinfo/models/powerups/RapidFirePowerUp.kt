package com.example.projetinfo.models.powerups

import com.example.projetinfo.models.PlayerShip
import com.example.projetinfo.models.PowerUp

class RapidFirePowerUp(x: Float, y: Float) : PowerUp(x, y) {
    override fun applyEffect(player: PlayerShip) {
        player.shootInterval = 150 // au lieu de 500 ms
    }
}
