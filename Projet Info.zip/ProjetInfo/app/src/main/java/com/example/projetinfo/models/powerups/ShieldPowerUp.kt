package com.example.projetinfo.models.powerups

import com.example.projetinfo.models.PowerUp
import com.example.projetinfo.models.PlayerShip

class ShieldPowerUp(x: Float, y: Float) : PowerUp(x, y) {
    override fun applyEffect(player: PlayerShip) {
        player.hasShield = true
    }
}
