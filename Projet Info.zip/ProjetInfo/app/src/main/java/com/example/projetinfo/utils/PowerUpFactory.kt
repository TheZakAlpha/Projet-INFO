package com.example.projetinfo.utils

import com.example.projetinfo.models.powerups.*
import com.example.projetinfo.models.PowerUp
import kotlin.random.Random

object PowerUpFactory {

    fun generateRandomPowerUp(level: Int): PowerUp {
        // Coordonnées aléatoires dans la zone de jeu
        val x = Random.nextFloat() * 900f + 100f  // évite les bords
        val y = Random.nextFloat() * 1200f + 100f

        // Choix aléatoire pondéré en fonction du niveau
        val types = when (level) {
            1 -> listOf(::SpeedBoostPowerUp, ::ShieldPowerUp)
            2 -> listOf(::SpeedBoostPowerUp, ::ShieldPowerUp, ::MultiShotPowerUp)
            3 -> listOf(::SpeedBoostPowerUp, ::ShieldPowerUp, ::MultiShotPowerUp, ::RapidFirePowerUp)
            else -> listOf(::MultiShotPowerUp, ::RapidFirePowerUp)
        }

        val type = types.random()
        return type.invoke(x, y).apply {
            // Tous les powerups ont une durée de vie de 10s sur l'écran
            this.setLifetime(10_000)
        }
    }
}
