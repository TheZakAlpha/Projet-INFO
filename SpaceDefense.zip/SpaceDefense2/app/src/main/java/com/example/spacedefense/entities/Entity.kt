package com.example.spacedefense.entities

import android.graphics.RectF

abstract class Entity (protected open var position: Pair<Float, Float>) {
    abstract var taille: Float
    abstract val color : Int
    abstract var direction : Pair<Float, Float>
    abstract var hitbox: RectF
    abstract var speed: Float
    abstract var damage: Int
    abstract var health: Int
    abstract var ally : Boolean
    var dead = false

    fun update(screenWidth: Int, screenHeight: Int) {
        val dx = direction.first * speed
        val dy = direction.second * speed

        // Collision avec les bords gauche et droit
        if (position.first + dx - taille / 2 < 0 || position.first + dx + taille / 2 > screenWidth) {
            direction = Pair(-direction.first, direction.second)
        }

        move(dx, dy)
        if(isOutOfScreen(screenHeight)) {
            die()
        }
    }

    protected open fun move(dx: Float, dy: Float) {
        position = Pair(position.first + dx, position.second + dy)
        updateHitbox()
    }

    protected fun updateHitbox() {
        hitbox = RectF(
            position.first - taille / 2,
            position.second - taille / 2,
            position.first + taille / 2,
            position.second + taille / 2
        )
    }

    private fun isOutOfScreen(screenHeight: Int): Boolean {
        return position.second - taille / 2 > screenHeight
    }

    fun takeDamage(damage: Int) {
        health -= damage
        if (health <= 0) die()
    }

    fun die() {
        dead= true
    }

    fun changeDirection(direction : Pair<Float, Float>) {
        this.direction = direction
    }

    fun getHitBox() : RectF {
        return hitbox
    }

}