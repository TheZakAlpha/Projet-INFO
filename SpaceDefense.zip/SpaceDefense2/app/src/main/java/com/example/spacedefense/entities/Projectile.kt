package com.example.spacedefense.entities

import android.graphics.Color
import android.graphics.RectF


class Projectile(override var position: Pair<Float, Float>,
                 override var direction: Pair<Float, Float>,
                 override var speed : Float,
                 override var damage : Int,
                 override var ally : Boolean) : Entity(position) {

    override var taille = 10f
    override var color = if (ally) Color.GREEN else Color.RED
    override var health = 1

    override var hitbox: RectF = RectF(
        position.first - taille / 2,
        position.second - taille / 2,
        position.first + taille / 2,
        position.second + taille / 2
    )
}

//class Projectile(
//     var position: Pair<Float, Float>,
//    private val speedY: Float,
//    private val isFromPlayer: Boolean // Pour pouvoir adapter la couleur ou collision plus tard
//) {
//    val taille = 10f
//    val color = if (isFromPlayer) Color.GREEN else Color.RED
//    val hitbox: RectF
//        get() = RectF(
//            position.first - taille / 2,
//            position.second - taille / 2,
//            position.first + taille / 2,
//            position.second + taille / 2
//        )
//
//    fun update() {
//        position = Pair(position.first, position.second + speedY)
//    }
//
//    fun isOutOfScreen(screenHeight: Int): Boolean {
//        return position.second + taille < 0 || position.second - taille > screenHeight
//    }
//}
