package com.example.spacedefense.entities.ennemies

import com.example.spacedefense.level.ShooterObserver

object EnemiesFactory {
    fun getRandomEnemy(position : Pair<Float, Float>, direction : Pair<Float, Float>, level : ShooterObserver) : Ennemi {
        val randomSpawnValue = (0..100).random()
        if(randomSpawnValue <= 40) {
            return getEnnemi(position, direction)
        } else if(randomSpawnValue <= 70) {
            return getFastEnnemi(position, direction)
        } else {
            return getEnnemiShooter(position, direction, level)
        }
    }

    fun getEnnemi(position : Pair<Float, Float>, direction : Pair<Float, Float>) : Ennemi {
        val ennemi = Ennemi(position)
        ennemi.changeDirection(direction)
        return ennemi
    }

    fun getFastEnnemi(position : Pair<Float, Float>, direction : Pair<Float, Float>) : Ennemi {
        val ennemi = FastEnnemi(position)
        ennemi.changeDirection(direction)
        return ennemi
    }

    fun getEnnemiShooter(position : Pair<Float, Float>, direction : Pair<Float, Float>, level : ShooterObserver) : Ennemi {
        val ennemi = EnnemiShooter(position, level)
        ennemi.changeDirection(direction)
        return ennemi
    }
}