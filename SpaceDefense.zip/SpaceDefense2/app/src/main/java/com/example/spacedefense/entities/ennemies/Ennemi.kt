package com.example.spacedefense.entities.ennemies

import android.graphics.Color
import android.graphics.RectF
import com.example.spacedefense.entities.Entity

open class Ennemi(override var position: Pair<Float, Float>) : Entity(position) {

    override var color = Color.CYAN
    override var health = 10
    override var taille = 40f
    override var direction: Pair<Float, Float> = Pair(0f, 1f) // Direction par défaut vers le bas
    override var speed = 6f
    override var damage = 5
    override var ally = false

    override var hitbox: RectF = RectF(
        position.first - taille / 2,
        position.second - taille / 2,
        position.first + taille / 2,
        position.second + taille / 2
    )
}
