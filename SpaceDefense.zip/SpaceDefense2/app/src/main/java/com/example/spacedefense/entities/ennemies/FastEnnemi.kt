package com.example.spacedefense.entities.ennemies

import android.graphics.Color

class FastEnnemi(position: Pair<Float, Float>) : Ennemi(position) {
    override var color = Color.YELLOW
    override var health = 5
    override var speed = 12f
}