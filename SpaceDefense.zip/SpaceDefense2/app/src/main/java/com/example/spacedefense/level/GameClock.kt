package com.example.spacedefense.level

class GameClock(private val level: LevelView) {

    private var running = false
    private val frameRate = 60
    private val frameDelay = (1000L / frameRate)

    private val gameLoop = object : Runnable {
        override fun run() {
            if (!running) return

            level.update()
            level.draw()

            level.postDelayed(this, frameDelay)
        }
    }

    fun start() {
        if (!running) {
            running = true
            level.post(gameLoop)
        }
    }

    fun stop() {
        running = false
    }
}
