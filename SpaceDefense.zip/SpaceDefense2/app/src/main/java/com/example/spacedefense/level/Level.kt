package com.example.spacedefense.level

import com.example.spacedefense.entities.ennemies.EnemiesFactory
import com.example.spacedefense.entities.ennemies.Ennemi
import com.example.spacedefense.entities.Personnage
import com.example.spacedefense.entities.Projectile
import com.example.spacedefense.entities.Shooter
import kotlin.math.sqrt
import kotlin.random.Random


class Level(private val levelView: LevelView, private val screenWidth : Int, private val screenHeight : Int) :
    ShooterObserver {
    private var personnage : Personnage = Personnage(Pair(screenWidth / 2F, screenHeight * 0.9F), this)
    private val ennemis = mutableListOf<Ennemi>()
    private var spawnTimer = 0
    private val spawnInterval = 60 // toutes les 60 frames (environ 1s si 60 fps)
    private val projectiles = mutableListOf<Projectile>()

    init {
        levelView.linkLevel(this) // linkée à LevelVIEW
    }

    fun update() {
        generateEnemies()

        removeDeadEnemies()
        removeDeadProjectiles()

        personnage.update(screenWidth)
        updateShooters()
        updateEnemies()
        updateProjectiles()

        checkCollisions()

        checkIfPlayerAlive()
    }

    private fun removeDeadEnemies() {
        val deadEnnemis = mutableListOf<Ennemi>()
        for (enemy in ennemis) {
            if (enemy.dead) {
                deadEnnemis.add(enemy)
            }
        }
        for (enemy in deadEnnemis) {
            ennemis.remove(enemy)
        }
    }

    private fun removeDeadProjectiles() {
        val deadProjectiles = mutableListOf<Projectile>()
        for (projectile in projectiles) {
            if (projectile.dead) {
                deadProjectiles.add(projectile)
            }
        }
        for (projectile in deadProjectiles) {
            projectiles.remove(projectile)
        }
    }

    private fun updateShooters() {
        for (enemy in ennemis) {
            if (enemy is Shooter) {
                enemy.tryShoot()
            }
        }
        personnage.tryShoot()
    }

    private fun generateEnemies() {
        spawnTimer++
        if (spawnTimer >= spawnInterval) {
            spawnTimer = 0
            spawnRandomEnnemi()
        }
    }

    private fun spawnRandomEnnemi() {
        val x = (50..(screenWidth - 50)).random().toFloat()
        val y = -50f
        val dx = Random.nextFloat() * 2f - 1f       // Entre -1f et 1f
        val dy = Random.nextFloat() * 0.5f + 0.5f   // Entre 0.5f et 1f
        val norme = sqrt(dx * dx + dy * dy)
        ennemis.add(EnemiesFactory.getRandomEnemy(Pair(x, y), Pair(dx / norme, dy / norme), this))
    }

    private fun updateEnemies() {
        for (enemy in ennemis) {
            enemy.update(screenWidth, screenHeight)
        }
    }

    private fun updateProjectiles() {
        for (projectile in projectiles) {
            projectile.update(screenWidth, screenHeight)
        }
    }

    private fun checkCollisions() {
        enemyCollideProjectile()
        projectileCollideProjectile()
        projectileCollidePersonnage()
        enemyCollidePersonnage()
    }

    private fun enemyCollideProjectile() {
        for (enemy in ennemis) {
            for (projectile in projectiles) {
                if (projectile.ally) {
                    if (enemy.getHitBox().intersect(projectile.getHitBox())) {
                        enemy.takeDamage(projectile.damage)
                        projectile.takeDamage(enemy.damage)
                    }
                }
            }
        }
    }

    private fun projectileCollideProjectile() {
        for (projectile1 in projectiles) {
            for (projectile2 in projectiles) {
                if (projectile1.ally && !projectile2.ally) {
                    if (projectile1.getHitBox().intersect(projectile2.getHitBox())) {
                        projectile1.takeDamage(projectile2.damage)
                        projectile2.takeDamage(projectile1.damage)
                    }
                }
            }
        }
    }

    private fun projectileCollidePersonnage() {
        for (projectile in projectiles) {
            if (!projectile.ally) {
                if (projectile.getHitBox().intersect(personnage.getHitBox())) {
                    projectile.die()
                    personnage.takeDamage(projectile.damage)
                }
            }
        }
    }

    private fun enemyCollidePersonnage() {
        for (enemy in ennemis) {
            if (enemy.getHitBox().intersect(personnage.getHitBox())) {
                enemy.die()
                personnage.takeDamage(enemy.damage)
            }
        }
    }

    private fun checkIfPlayerAlive() {
        if(personnage.dead) {
            System.exit(0)
            // TODO
        }
    }

    fun changePersonnageDirection(direction : Int) {
        personnage.changeDirection(direction)
    }

    fun getPersonnage() : Personnage {
        return personnage
    }

    fun getEnnemis(): List<Ennemi> {
        return ennemis
    }

    fun getProjectiles(): List<Projectile> {
        return projectiles
    }

    override fun addProjectile(projectile: Projectile) {
        projectiles.add(projectile)
    }


}