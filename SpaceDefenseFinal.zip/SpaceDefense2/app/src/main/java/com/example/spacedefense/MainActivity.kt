package com.example.spacedefense

import android.os.Bundle
import android.util.DisplayMetrics
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import com.example.spacedefense.level.Level
import com.example.spacedefense.level.LevelView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.main_activity)
        var levelview = findViewById<LevelView>(R.id.levelView)
        levelview.setWillNotDraw(false)
        levelview.invalidate()
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)

        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels
        var level = Level(levelview, screenWidth, screenHeight)
        levelview.draw()
    }
}

