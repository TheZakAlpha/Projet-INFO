package com.example.spacedefense.entities.ennemies

import android.content.Context
import android.graphics.Color
import android.graphics.RectF
import com.example.spacedefense.entities.Projectile
import com.example.spacedefense.level.ShooterObserver
import kotlin.math.cos
import kotlin.math.sin
import com.example.spacedefense.entities.Shooter

class Boss(
    position: Pair<Float, Float>,
    override var level: ShooterObserver,
    context: Context
) : Ennemi(position, context), Shooter {

    override var color = Color.MAGENTA
    override var health = 1
    override var taille = 150f
    override var speed = 0f
    override var damage = 10
    override var ally = false
    override var shootRate = 40
    override var lastShoot = 0
    override var hitbox: RectF = RectF(
        position.first - taille / 2,
        position.second - taille / 2,
        position.first + taille / 2,
        position.second + taille / 2)

    //override val bitmap = bitmap // À adapter plus tard si image spécifique

    override fun shoot() {
        if ((0..100).random() <= 50) {
            shootRafale()
        } else {
            shootEnAngle()
        }
    }

    private fun shootRafale() {
        // Tir de 5 projectiles rapides vers le bas
        for (i in -2..2) {
            val dx = i * 0.2f
            val dy = 1f
            val projectile = Projectile(
                Pair(hitbox.centerX(), hitbox.bottom),
                Pair(dx, dy),
                15f,
                3,
                false,
                this


            )
            level.addProjectile(projectile)
        }
    }

    private fun shootEnAngle() {
        // Tir en étoile autour du boss
        val angles = listOf(45,60, 90,110, 135)
        for (angle in angles) {
            val rad = Math.toRadians(angle.toDouble())
            val dx = cos(rad).toFloat()
            val dy = sin(rad).toFloat()

            val projectile = Projectile(
                Pair(hitbox.centerX(), hitbox.bottom),
                Pair(dx, dy),
                12f,
                2,
                false,
                this
            )
            level.addProjectile(projectile)
        }
    }

    override fun update(screenWidth: Int, screenHeight: Int) {
        // Boss immobile mais tir régulièrement
        tryShoot()
    }


}
