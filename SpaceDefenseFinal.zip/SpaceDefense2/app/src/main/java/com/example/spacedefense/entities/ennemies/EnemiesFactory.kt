package com.example.spacedefense.entities.ennemies

import com.example.spacedefense.level.ShooterObserver
import android.content.Context

object EnemiesFactory {
    fun getRandomEnemy(position : Pair<Float, Float>, direction : Pair<Float, Float>, level : ShooterObserver,context: Context) : Ennemi {
        val randomSpawnValue = (0..100).random()
        if(randomSpawnValue <= 40) {
            return getEnnemi(position, direction,context)
        } else if(randomSpawnValue <= 70) {
            return getFastEnnemi(position, direction,context)
        } else {
            return getEnnemiShooter(position, direction, level, context)
        }
    }

    fun getEnnemi(position : Pair<Float, Float>, direction : Pair<Float, Float>, context: Context) : Ennemi {
        val ennemi = Ennemi(position, context)
        ennemi.changeDirection(direction)
        return ennemi
    }

    fun getFastEnnemi(position : Pair<Float, Float>, direction : Pair<Float, Float>, context: Context) : Ennemi {
        val ennemi = FastEnnemi(position,context)
        ennemi.changeDirection(direction)
        return ennemi
    }

    fun getEnnemiShooter(position : Pair<Float, Float>, direction : Pair<Float, Float>, level : ShooterObserver, context: Context) : Ennemi {
        val ennemi = EnnemiShooter(position, level, context)
        ennemi.changeDirection(direction)
        return ennemi
    }
}