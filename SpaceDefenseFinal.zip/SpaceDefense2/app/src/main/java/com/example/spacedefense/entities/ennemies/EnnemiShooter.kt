package com.example.spacedefense.entities.ennemies

import android.graphics.Color
import com.example.spacedefense.entities.Projectile
import com.example.spacedefense.entities.Shooter
import com.example.spacedefense.level.ShooterObserver
import android.content.Context

open class EnnemiShooter(position: Pair<Float, Float>, override var level: ShooterObserver, context: Context)
    : Ennemi(position, context), Shooter {

    override var color = Color.RED
    override var health = 5
    override var shootRate = 60
    override var lastShoot = 0

    override fun shoot() {
        val projectile =
            Projectile(Pair(hitbox.centerX(), hitbox.bottom), Pair(0f, 1f), 20f, 2, false)
        level.addProjectile(projectile)
    }
}