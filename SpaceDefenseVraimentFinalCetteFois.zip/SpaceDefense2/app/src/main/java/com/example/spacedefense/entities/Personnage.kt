package com.example.spacedefense.entities

import android.graphics.Color
import android.graphics.RectF
import com.example.spacedefense.level.ShooterObserver

class Personnage(override var position : Pair<Float, Float>, override var level: ShooterObserver)
    : Entity(position), Shooter {

    override var taille = 50F
    override var color = Color.WHITE
    override var hitbox = RectF(position.first - taille/2,position.second - taille/2,position.first + taille/2,position.second + taille/2)
    override var direction = Pair(0f, 0f) // -1 = gauche, 1 = droite, 0 = stop
    override var speed = 12f
    override var damage = 5
    override var health = 10
    override var ally = true
    override var shootRate = 20
    override var lastShoot = 0

    fun changeDirection(value: Int) {
        direction = Pair(value.toFloat(), 0f)
    }

    override fun move(dx: Float, dy: Float) {
        position = Pair(position.first + dx, position.second + dy)
        updateHitbox()
    }

    fun update(screenWidth : Int) {
        if (direction.first != 0f) {
            if (position.first + speed*direction.first + taille/2> screenWidth || position.first +speed*direction.first < 0 + taille/2)
                return
            move(direction.first * speed, 0f)
        }
    }

    override fun shoot() {
        val projectile = Projectile(Pair(hitbox.centerX(), hitbox.top), Pair(0f, -1f), 40f, damage, true)
        level.addProjectile(projectile)
    }

}