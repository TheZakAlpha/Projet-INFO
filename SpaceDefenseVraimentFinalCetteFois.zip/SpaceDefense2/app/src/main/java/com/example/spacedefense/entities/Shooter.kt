package com.example.spacedefense.entities

import com.example.spacedefense.level.ShooterObserver

interface Shooter {
    var level : ShooterObserver
    var shootRate: Int
    var lastShoot: Int
    fun shoot()

    fun tryShoot() {
        lastShoot++
        if(lastShoot >= shootRate) {
            shoot()
            lastShoot = 0
        }

    }
}