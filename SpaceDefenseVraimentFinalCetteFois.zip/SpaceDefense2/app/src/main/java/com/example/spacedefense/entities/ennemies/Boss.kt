package com.example.spacedefense.entities.ennemies

import android.graphics.Color
import com.example.spacedefense.entities.Projectile
import com.example.spacedefense.entities.Shooter
import com.example.spacedefense.level.ShooterObserver
import android.content.Context

class Boss(position: Pair<Float, Float>, override var level: ShooterObserver, context: Context)
    : Ennemi(position,context), Shooter {

    override var taille = 160f
    override var color = Color.MAGENTA
    override var health = 15
    override var shootRate = 30
    override var lastShoot = 0

    override fun shoot() {
        val projectile =
            Projectile(Pair(hitbox.centerX(), hitbox.bottom), Pair(0f, 1f), 20f, 2, false)
        level.addProjectile(projectile)

        val projectile2 =
            Projectile(Pair(hitbox.centerX(), hitbox.bottom), Pair(-1f, 1f), 20f, 2, false)
        level.addProjectile(projectile2)

        val projectile3 =
            Projectile(Pair(hitbox.centerX(), hitbox.bottom), Pair(1f, 1f), 20f, 2, false)
        level.addProjectile(projectile3)

        val projectile4 =
            Projectile(Pair(hitbox.centerX(), hitbox.bottom), Pair(0.5f, 1f), 20f, 2, false)
        level.addProjectile(projectile4)

        val projectile5 =
            Projectile(Pair(hitbox.centerX(), hitbox.bottom), Pair(-0.5f, 1f), 20f, 2, false)
        level.addProjectile(projectile5)
    }
}