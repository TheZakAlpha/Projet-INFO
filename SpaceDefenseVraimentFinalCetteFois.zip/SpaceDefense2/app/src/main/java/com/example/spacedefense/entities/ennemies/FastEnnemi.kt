package com.example.spacedefense.entities.ennemies

import android.graphics.Color
import android.content.Context

class FastEnnemi(position: Pair<Float, Float>, context: Context) : Ennemi(position,context) {
    override var color = Color.YELLOW
    override var health = 5
    override var speed = 12f
}