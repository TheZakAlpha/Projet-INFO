package com.example.spacedefense.level

class GameClock(open val level: LevelView) {

    private var running = false
    private val frameRate = 60
    private val frameDelay = (1000L / frameRate)
    private var frameCount = 0

    private val gameLoop = object : Runnable {
        override fun run() {
            if (!running) return

            level.update()
            level.draw()
            frameCount++


            // fais spawn le boss a un intervalle de temps en frame
            if (frameCount %300 == 0 && frameCount != 0 ) {
                level.level.spawnBoss()
            }



            level.postDelayed(this, frameDelay)
        }
    }

    fun start() {
        if (!running) {
            running = true
            level.post(gameLoop)
        }
    }

    fun stop() {
        running = false
    }
}
