package com.example.spacedefense.level

import com.example.spacedefense.entities.Projectile

interface ShooterObserver {
    fun addProjectile(projectile: Projectile)
}