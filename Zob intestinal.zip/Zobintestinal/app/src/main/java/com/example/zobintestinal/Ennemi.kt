package com.example.zobintestinal

import android.graphics.Color
import android.graphics.RectF

class Ennemi(var position: Pair<Float, Float>) {

    val taille = 40f
    val color = Color.RED
    var direction: Pair<Float, Float> = Pair(0f, 1f) // Direction par défaut vers le bas
    private val speed = 6f

    var hitbox: RectF = RectF(
        position.first - taille / 2,
        position.second - taille / 2,
        position.first + taille / 2,
        position.second + taille / 2
    )

    fun update(screenWidth: Int, screenHeight: Int) {
        val dx = direction.first * speed
        val dy = direction.second * speed

        // Collision avec les bords gauche et droit
        if (position.first + dx - taille / 2 < 0 || position.first + dx + taille / 2 > screenWidth) {
            direction = Pair(-direction.first, direction.second)
        }

        move(dx, dy)
    }

    private fun move(dx: Float, dy: Float) {
        position = Pair(position.first + dx, position.second + dy)
        updateHitbox()
    }

    private fun updateHitbox() {
        hitbox = RectF(
            position.first - taille / 2,
            position.second - taille / 2,
            position.first + taille / 2,
            position.second + taille / 2
        )
    }

    fun isOutOfScreen(screenHeight: Int): Boolean {
        return position.second - taille / 2 > screenHeight
    }
}
