package com.example.zobintestinal

import kotlin.math.sqrt
import kotlin.random.Random


class Level(private val levelVIOU: LevelVIOU, private val screenWidth : Int, private val screenHeight : Int) {
    private var personnage : PPPPPPPERSONAGE = PPPPPPPERSONAGE(Pair(screenWidth/2F, screenHeight*0.9F))
    private val ennemis = mutableListOf<Ennemi>()
    private var spawnTimer = 0
    private val spawnInterval = 60 // toutes les 60 frames (environ 1s si 60 fps)
    private val projectiles = mutableListOf<Projectile>()
    private var tirTimer = 0
    private val tirInterval = 30 // toutes les 15 frames



    init {
        levelVIOU.linkLevel(this)
    }
    //  linkée à LevelVIEW
    fun update() {
        personnage.update(screenWidth)

        // Tir du perso
        tirTimer++
        if (tirTimer >= tirInterval) {
            tirerDepuisPersonnage()
            tirTimer = 0
        }

        // Génère le spawn des ennemis
        spawnTimer++
        if (spawnTimer >= spawnInterval) {
            spawnTimer = 0
            spawnEnnemi()
        }

        // Mise à jour des ennemis
        val ennemiIterator = ennemis.iterator()
        while (ennemiIterator.hasNext()) {
            val ennemi = ennemiIterator.next()
            ennemi.update(screenWidth, screenHeight)
        }

        // Mise à jour des projectiles
        val projectileIterator = projectiles.iterator()
        while (projectileIterator.hasNext()) {
            val proj = projectileIterator.next()
            proj.update()
            if (proj.isOutOfScreen(screenHeight)) {
                projectileIterator.remove()
            }
        }
    }

    private fun spawnEnnemi() {
        val x = (50..(screenWidth - 50)).random().toFloat()
        val y = -50f
        val ennemi = Ennemi(Pair(x, y))

        // moves aléatoires ( pas purement Y+ ni horizontal )
        val dx = Random.nextFloat() * 2f - 1f       // Entre -1f et 1f
        val dy = Random.nextFloat() * 0.5f + 0.5f   // Entre 0.5f et 1f

        val magnitude = sqrt(dx * dx + dy * dy)
        ennemi.direction = Pair(dx / magnitude, dy / magnitude)

        ennemis.add(ennemi)
    }
    // Tir du perso
    fun tirerDepuisPersonnage() {
        val perso = getPersonnage()
        val projectile = Projectile(
            position = Pair(perso.hitbox.centerX(), perso.hitbox.top),
            speedY = -20f,
            isFromPlayer = true
        )
        projectiles.add(projectile)
    }



    fun changePersonnageDirection(direction : Int) {
        personnage.direction = direction
    }

    fun getPersonnage() : PPPPPPPERSONAGE {
        return personnage
    }

    fun getEnnemis(): List<Ennemi> {
        return ennemis
    }

    fun getProjectiles(): List<Projectile> {
        return projectiles
    }


}