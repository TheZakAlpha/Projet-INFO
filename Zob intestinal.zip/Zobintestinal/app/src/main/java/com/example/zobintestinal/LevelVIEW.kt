package com.example.zobintestinal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceView
import android.view.SurfaceHolder
import android.view.MotionEvent
import com.example.zobintestinal.ui.theme.GameClock


class LevelVIOU @JvmOverloads constructor(
    context: Context, attributes: AttributeSet? = null, defStyleAttr: Int = 0
) : SurfaceView(context, attributes, defStyleAttr), SurfaceHolder.Callback {

    private lateinit var canvas: Canvas
    private lateinit var level: Level
    private val gameClock = GameClock(this)

    init {
        holder.addCallback(this)
    }
    fun linkLevel(level: Level) {
        this.level = level
    }

    fun update() {
        level.update()
    }
    //  DESSINE BONHOMME
    fun draw() {
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()
            redrawBackground()
            drawpersonnage()
            drawEnnemis()
            drawProjectiles()
            holder.unlockCanvasAndPost(canvas)
        }
    }
    // tous les dessins
    private fun drawpersonnage() {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = level.getPersonnage().color
        canvas.drawRect(level.getPersonnage().hitbox, paint)
    }

    private fun drawEnnemis() {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.RED
        for (ennemi in level.getEnnemis()) {
            canvas.drawRect(ennemi.hitbox, paint)
        }
    }

    private fun drawProjectiles() {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        for (proj in level.getProjectiles()) {
            paint.color = proj.color
            canvas.drawRect(proj.hitbox, paint)
        }
    }


    private fun redrawBackground() {
        canvas.drawColor(Color.BLACK)
    }
    //  ça je comprend pas de fou, moyen chaud l'effacer pour le moment
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val screenWidth = width
            val x = event.x
            level.changePersonnageDirection(if (x < screenWidth / 2) -1 else 1)
            return true
        } else if (event.action == MotionEvent.ACTION_UP) {
            level.changePersonnageDirection(0)
        }
        return super.onTouchEvent(event)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        gameClock.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) {
        gameClock.stop()
    }
}
