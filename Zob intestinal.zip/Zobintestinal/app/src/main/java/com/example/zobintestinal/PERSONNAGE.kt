package com.example.zobintestinal

import android.graphics.Color
import android.graphics.RectF

class PPPPPPPERSONAGE(private var position : Pair<Float, Float>) {
    val taille = 50F
    val color = Color.WHITE
    var hitbox = RectF(position.first - taille/2,position.second - taille/2,position.first + taille/2,position.second + taille/2)
    var direction = 0 // -1 = gauche, 1 = droite, 0 = stop
    private val speed = 12f


    fun move(dx: Float, dy: Float) {
        position = Pair(position.first + dx, position.second + dy)
        updateHitbox()
    }

    fun update(screenWidth : Int) {
        if (direction != 0) {
            if (position.first + speed*direction + taille/2> screenWidth || position.first +speed*direction < 0 + taille/2)
                return
            move(direction * speed, 0f)
        }

    }


    private fun updateHitbox() {
        hitbox = RectF(
            position.first - taille / 2,
            position.second - taille / 2,
            position.first + taille / 2,
            position.second + taille / 2
        )
    }
}