package com.example.zobintestinal

import android.graphics.Color
import android.graphics.RectF

class Projectile(
     var position: Pair<Float, Float>,
    private val speedY: Float,
    private val isFromPlayer: Boolean // Pour pouvoir adapter la couleur ou collision plus tard
) {
    val taille = 10f
    val color = if (isFromPlayer) Color.GREEN else Color.RED
    val hitbox: RectF
        get() = RectF(
            position.first - taille / 2,
            position.second - taille / 2,
            position.first + taille / 2,
            position.second + taille / 2
        )

    fun update() {
        position = Pair(position.first, position.second + speedY)
    }

    fun isOutOfScreen(screenHeight: Int): Boolean {
        return position.second + taille < 0 || position.second - taille > screenHeight
    }
}
